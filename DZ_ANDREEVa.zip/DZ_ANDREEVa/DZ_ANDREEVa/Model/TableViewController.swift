//
//  TableViewController.swift
//  DZ_ANDREEVa
//
//  Created by Юлия Андреева on 07.11.2020.
//  Copyright © 2020 IULIIA ANDREEVA. All rights reserved.
//
import UIKit

class TableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
}
